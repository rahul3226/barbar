<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Model;

class UserRegisterRequest
{
    public ?string $id = null;
    public ?string $name = null;
    public ?string $password = null;
}