<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Model;

class UserProfileUpdateRequest
{
    public ?string $id = null;
    public ?string $name = null;
}