<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Model;

use ProgrammerZamanNow\Belajar\PHP\MVC\Domain\User;

class UserPasswordUpdateResponse
{
    public User $user;
}