<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Model;

class UserLoginRequest
{
    public ?string $id = null;
    public ?string $password = null;
}