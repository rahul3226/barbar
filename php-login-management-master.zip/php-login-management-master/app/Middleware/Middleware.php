<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Middleware;

interface Middleware
{

    function before(): void;

}