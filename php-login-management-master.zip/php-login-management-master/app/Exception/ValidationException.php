<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Exception;

class ValidationException extends \Exception
{

}