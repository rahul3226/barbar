<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Domain;

class User
{
    public string $id;
    public string $name;
    public string $password;
}